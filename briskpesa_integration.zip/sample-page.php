<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="BriskPesa sample page">
    <meta name="author" content="Mobiworld">

    <title>BriskPesa Sample Page</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

	<style type="text/css">
		body {
		  padding-top: 50px;
		}
		.starter-template {
		  padding: 40px 15px;
		  text-align: center;
		}
	</style>
  </head>

  <body>

    <div class="container col-md-6 col-md-offset-3">
      <div class="starter-template">
        <h1>BriskPesa Intergration</h1>
      </div>
	  <div class="briskpesa"> </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>    
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
	<script src="briskpesa.min.js"></script>
	<script>
		$( ".briskpesa" ).briskPesa({
					checkoutUrl: "checkout.php",
					pollUrl: "poll.php",
					showPayButton: true,
					payButtonText: "Pay",
					success: function(data) {
					   console.log(data);
					},
					error: function(data) {
					   console.log(data);
					},
				});
	</script>

  </body>
</html>
