
BriskPesa Integration.
=========================

There are 2 files involved :-
BriskPesaGateway.php - a php library for briskpesa gateway. Use this to create checkout and poll endpoints.
briskpesa.min.js - a javascript library. Use this on your html to create payment form.

Sample files are also included :-
checkout.php - for requesting payment. Modify as needed.
poll.php - for checking status of payment. Modify as needed.
sample-page.php - a sample of how javascript library has been used.

Please look at the sample-page. Understanding it will help you understand how the library works.

NOTES :-
The javascript library requires an empty div where you want the payment form to appear. If you have amount or phone number preset, set it as a data attribute to the div. Setting phone or amount as data attribute means users will not enter it. Examples:-

	<div class="briskpesa" data-amount="10" data-phone="07xxxxxxxx"> </div> <!-- Both phone and amount are preset -->
	<div class="briskpesa"> </div> </div> <!-- no parameter is preset -->

Then instantiate the library as follows :-

	$( ".briskpesa" ).briskPesa( options )

Options are as follows :-
checkoutUrl - checkout url. Default is checkout.php. Needs to be on your server
pollUrl - poll url. Default is poll.php. Needs to be on your server
success - function called when payment is successful
error - function called when payment fails
showPayButton - whether to show pay button (Default: True). Set it to false if you have your own button.
payButtonText - text shown on the pay button (Default: Pay).

ADVANCED :-
In case you need to execute payment when your own button is clicked or another event is fired, do it as follows :-
1. Instantiate the library the usual way but save results as a variable.
	var briskpesa = $( ".briskpesa" ).briskPesa( options )
2. Execute requestPayment function of the created variable as shown below.
	briskpesa.requestPayment({phone:"254715795302",amount:"10", success: success_fxn, error: error_fxn});
	
	NB: create success_fxn and error_fxn first e.g.
		var success_fxn = function (data) {
	        console.log("from test: " + data);
	    };
		var error_fxn = function (data) {
	        console.log("from test: " + data);
	    };



